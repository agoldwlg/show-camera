#ifndef _TRACK_VIEW_H_
#define _TRACK_VIEW_H_

#include <androidfw/AssetManager.h>

#include "ViewBase.h"

namespace android {

class TrackView: public ViewBase
{
private:
    Mutex mLock;
    Condition mCondition;
    bool mSurfaceDirty;

    GLuint mProgram;
    GLuint mPositionHandle;
    GLuint mMVPMatrixHandle;
    GLuint mColorHandle;

    GLuint mOverlayProgram;
    GLuint mOverlayPositionHandle;
    GLuint mOverlayTextureCoordHandle;
    GLuint mOverlayTexName;

    AssetManager mAssets;

    float mW; // ??????(????).
    float mL;  // ??????.
    float mD; // ?????????.
    float mH; // ????????????
    float mOA;// ?????
    float mIA;// ??????????
    float mCA; // ??????
    float mTL; // ?????
    float mAspect;
    float mRate; // ?????????.
    float mLw; //?????
 

    float* mVerticesR; // right line
    float* mVerticesL; // left line
    float* mVerticesB; //bottom line
    int N;
    float eyeX, eyeY, eyeZ;
    float centerX, centerY, centerZ;
    float upX, upY, upZ;
    float mNear, mFar;

	int mSteeringValid;

public:
    TrackView ();
    virtual ~TrackView ();
    virtual void update(void* data);

private:
    void initConfig();
    status_t initTexture(GLuint* textureName, AssetManager& assets, const char* name, bool egl2);
    void updateViewParams();
    void updateLineVertices();
    void drawTrack();
    void drawStaticTrack();
    void drawDynamicTrack();
    void drawLine(const void* pointer, const GLfloat* color, int num);
    virtual bool threadLoop_l ();

};

};
#endif
