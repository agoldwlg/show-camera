 #ifndef _RADAR_VIEW_H_
#define _RADAR_VIEW_H_

#include <androidfw/AssetManager.h>
#include <utils/Log.h>


#include "ViewBase.h"

static const int O_SEGMENT1 = 40;
static const int O_SEGMENT2 = 65;

static const int M_SEGMENT1 = 40;
static const int M_SEGMENT2 = 100;
static const int M_SEGMENT3 = 150;


typedef struct SegmentInfo_t{
	GLint x;
	GLint y;
	GLint w;
	GLint h;
	const char* images[4]; 
	GLuint texIds[4];
	int currentIndex;
} SegmentInfo;

typedef struct Notice_SegmentInfo_t{
	const char* image; 
	GLuint texId;
} NoticeSegmentInfo;

enum{
	ALARM_MUTE = 1,
	ALARM_2HZ = 2,
	ALARM_4HZ = 3,
	ALARM_LONG_BEEP = 4,
};

namespace android {


class RadarView: public ViewBase
{
private:
    Mutex mLock;
    Condition mCondition;
    AssetManager mAssets;
    struct RadarData{
        int ROL;
        int ROR;
        int RML;
        int RMR;
    };
struct RadarStatus{
        int ROL_STATUS;
        int ROR_STATUS;
        int RML_STATUS;
        int RMR_STATUS;
    };
    bool mSurfaceDirty;
    RadarData mRadarData;
	RadarStatus mRadarsStatus;
    /*
    * 0 disable
    * 1 slow
    * 2 mid slow
    * 3 fast
    * 4 roll
    */
    uint8_t mAlarmType;
    /*
    * 0 small
    * 1 mid
    * 2 big
    */
    int mAlarmVolume;
	int mRadarStatus;
	int mRadarSysStatus;

public:
    RadarView();
    virtual ~RadarView();
    virtual bool threadLoop_l();
    virtual void update(void* p_data);
    void updateImageAndAlarmType ();
    status_t applyAlarmType();
    int setAlarmType(uint8_t type);
private:
    status_t initTexture(int i);
    void drawTexture(SegmentInfo* segInfo);
	status_t initNoticeTexture(int i);
    void drawNoticeTexture();
};
};
#endif
