#define LOG_TAG "PAS_EventHandle"

// #define LOG_NDEBUG 0

#include "EventHandle.h"
#include "ViewModule.h"
#include "Event.h"
#include <string.h>
#include <cutils/properties.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
static const char *PAS_DIAPLAY_STATUS_FILE = "/data/pas_display_status";

namespace android {

EventHandle::EventHandle() {
    mStatusChanged = false;
    mAccOn = STATE_ON;
    mReverseOn = STATE_OFF;
    mRVCOn = STATE_OFF;
    mView = new ViewModule();
    mForceDisplay = false;
	strcpy(mForceDisplayProp, "stop");
    if (access(PAS_DIAPLAY_STATUS_FILE, F_OK) == -1) {
        ALOGE("access file not exsit.");
        umask(0000);
        int fd = open(PAS_DIAPLAY_STATUS_FILE, O_RDWR|O_CREAT|O_TRUNC, 0644);
        if (fd < 0) {
            ALOGE("could not open file: %s : %s", PAS_DIAPLAY_STATUS_FILE, strerror(errno));
        }
        close(fd);
    }    
}

EventHandle::~EventHandle() {

}

void EventHandle:: onFirstRef (){
    run("EventHandle", PRIORITY_DISPLAY);
}

void EventHandle::handleStatusEvent(int event, State state)
{
    bool flag_changed = false;
    Mutex::Autolock _l(mStatusLock);
    switch(event){
    case EVENT_ACC:
        if(mAccOn!=state) {
            mAccOn=state;
            flag_changed = true;
        }
        break;
    case EVENT_REVERSE:
        if(mReverseOn!= state) {
            mReverseOn = state;
            flag_changed = true;
        }
        break;
    case EVENT_RVC_STATUS:
         if(mRVCOn!= state) {
            mRVCOn = state;
            flag_changed = true;
        }
        break;
    }
    if(flag_changed) {
        mStatusChanged = true;
        mCondition.broadcast();
    }
}

bool EventHandle:: processEvent(int event, void* p_data){
    State state;
    switch(event){
        case EVENT_ACC:
        case EVENT_REVERSE:
        case EVENT_RVC_STATUS:
            state = *((State*)p_data);
            handleStatusEvent(event, state);
            break;
        case EVENT_STEERING:
        case EVENT_RADAR:
            mView->processEvent(event, p_data);
            break;
    }
    return true;
}
bool EventHandle:: writePasDisplayStatus(const char* status) {
    int fd;
    char forceDisplayStatus[10];
    umask(0000);
    fd = open(PAS_DIAPLAY_STATUS_FILE, O_RDWR|O_CREAT|O_TRUNC, 0644);
    if(fd < 0) {
        ALOGE("writePasDisplayStatus could not open %s, %s\n", PAS_DIAPLAY_STATUS_FILE, strerror(errno));
        return -1;
    }
    strcpy(forceDisplayStatus,status);
    write(fd,forceDisplayStatus,strlen(status));
    close(fd);
    return true;
}

bool EventHandle:: threadLoop(){
    int accOn, reverseOn,rvcOn;
    while(!exitPending())
    {
        {
            Mutex::Autolock _l(mStatusLock);
            while(!mStatusChanged)
            {
                if(mCondition.waitRelative(mStatusLock, milliseconds(100))!=NO_ERROR)
                    break;
            }
            accOn = mAccOn;
            reverseOn = mReverseOn;
            rvcOn = mRVCOn;
            mStatusChanged = false;
        }
    if((accOn==STATE_ON&&reverseOn==STATE_ON) || mRVCOn == STATE_ON){
            if(!mView->isDisplaying()){
                writePasDisplayStatus("start");
                mView->display();
            }
        }else{
            if(mView->isDisplaying()){
                writePasDisplayStatus("stop");
                mView->dismiss();
            }
        }
    }
    return true;
}

}
