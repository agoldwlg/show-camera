#ifndef MATRIX_UTILS_H
#define MATRIX_UTILS_H

#include <GLES/gl.h>

#define PI 3.14159265358979323846f

void gluLookAt(float eyeX, float eyeY, float eyeZ,
        float centerX, float centerY, float centerZ, float upX, float upY,
        float upZ);

void gluPerspective(GLfloat fovy, GLfloat aspect,
                           GLfloat zNear, GLfloat zFar);

void perspectiveM(GLfloat* m, GLfloat fovy, GLfloat aspect, GLfloat zNear, GLfloat zFar);

void frustumM(GLfloat* m, GLfloat left, GLfloat right, GLfloat bottom, GLfloat top, GLfloat near,
	GLfloat far);

void lookAtM(float* m, float eyeX, float eyeY, float eyeZ,
        float centerX, float centerY, float centerZ, float upX, float upY,
        float upZ) ;

void translateM(GLfloat* m, GLfloat x, GLfloat y, GLfloat z);

void multiplyMM(float* r, const float* lhs, const float* rhs);

void rotateM(float* m, float a, float x, float y, float z);
#endif