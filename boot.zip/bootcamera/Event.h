#ifndef _PAS_EVENT_H
#define _PAS_EVENT_H

typedef enum {
	EVENT_ACC = 1,
	EVENT_REVERSE = 2,
	EVENT_STEERING = 3,
	EVENT_RADAR = 4,
    EVENT_RVC_STATUS = 5
}Event;

typedef enum {
	STATE_ON = 0,
	STATE_OFF = 1,
	STATE_UNKNOWN = -1
}State;

enum{
    PIL_ACC_MSG = 1001,
    PIL_SWA_MSG = 1006,
    PIL_PDC_MSG = 1005
};

enum {
    RADAR_ROL = 1,
    RADAR_RML = 2,
    RADAR_RMR = 3,
    RADAR_ROR = 4
};

typedef union SensorData_t {
    struct {
        int type;
        int value;
        int status;
    }sensor;
    int array[3];
	
}SensorData;
typedef struct PdcData_t {
    int status;
    int alarmType;
    int number;
    SensorData sensor[4];
} PdcData;

typedef struct SteeringData_t {
    float ca;
    int valid;
} SteeringData;

#endif
