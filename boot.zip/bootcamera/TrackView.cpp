#define LOG_NDEBUG 0
#define LOG_TAG "PAS_TrackView"

#include <stdint.h>
#include <sys/types.h>
#include <math.h>
#include <utils/Log.h>
#include <cstdlib>
#include <SkBitmap.h>
#include <SkStream.h>
#include <SkImageDecoder.h>
#include <cutils/properties.h>
#include "Event.h"
#include "TrackView.h"
#include "MatrixUtils.h"
#include <fcntl.h>

static const char *DISTANCE_CAMERA_REAR_AXLE = "sys.pas.dis_CRA";
static const char *CAMERA_ANGLE = "sys.pas.CA";
static const char *CAMERA_LOCATION = "sys.pas.CL";
static const char *ANGLE_CAMERA_PLANE = "sys.pas.ACP";
static const char *REAR_AXLE_LENGTH = "sys.pas.RAL";
static const char *WHEEL_BASE = "sys.pas.WB";
static const char *TRACK_LENGTH = "sys.pas.TL";
static const char *STEERING_ANGLE = "sys.pas.SA";
static const char *BACKSERVICE_RVC_STATUS_FILE = "/data/backservice_rvc_status";

namespace android {

TrackView::TrackView():ViewBase("trackview")
{
    mSurfaceDirty = true;
    N = 20;

    mVerticesL = (float*)malloc((N+1)*2*3*sizeof(float));
    if(!mVerticesL) {
         ALOGE("malloc failed:%lu", (N+1)*2*3*sizeof(float));
         return;
    }
    mVerticesR = (float*)malloc((N+1)*2*3*sizeof(float));
    if(!mVerticesR) {
         ALOGE("malloc failed:%lu", (N+1)*2*3*sizeof(float));
         return;
    }
    mVerticesB = (float*)malloc(4*3*sizeof(float));
    if(!mVerticesB) {
         ALOGE("malloc failed:%lu", (4*3*sizeof(float)));
         return;
    }
    initConfig();
}

TrackView::~TrackView ()
{
    if(mVerticesL) {
        free(mVerticesL);
        mVerticesL=NULL;
    }
    if(mVerticesR) {
        free(mVerticesR);
        mVerticesR=NULL;
    }
    if(mVerticesB) {
        free(mVerticesB);
        mVerticesB=NULL;
    }
}

status_t TrackView::initTexture(GLuint* textureName, AssetManager& assets,
        const char* name, bool egl2){
    Asset* asset = assets.open(name, Asset::ACCESS_BUFFER);
    if (asset == NULL)
        return NO_INIT;
    SkBitmap bitmap;
    SkImageDecoder::DecodeMemory(asset->getBuffer(false), asset->getLength(),
            &bitmap, kUnknown_SkColorType, SkImageDecoder::kDecodePixels_Mode);
    asset->close();
    delete asset;

    // ensure we can call getPixels(). No need to call unlock, since the
    // bitmap will go out of scope when we return from this method.
    bitmap.lockPixels();

    const int w = bitmap.width();
    const int h = bitmap.height();
    const void* p = bitmap.getPixels();

    GLint crop[4] = { 0, h, w, -h };

    glGenTextures(1, textureName);
    glBindTexture(GL_TEXTURE_2D, *textureName);

    //ALOGD("colorType=%d" , bitmap.colorType());
    switch (bitmap.colorType()) {
        case kAlpha_8_SkColorType:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_ALPHA, w, h, 0, GL_ALPHA,
                    GL_UNSIGNED_BYTE, p);
            break;
        case kARGB_4444_SkColorType:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA,
                    GL_UNSIGNED_SHORT_4_4_4_4, p);
            break;
        case kN32_SkColorType:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA,
                    GL_UNSIGNED_BYTE, p);
            break;
        case kRGB_565_SkColorType:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, w, h, 0, GL_RGB,
                    GL_UNSIGNED_SHORT_5_6_5, p);
            break;
        default:
            break;
    }

    if(egl2)
    {
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    }
    else
    {
    glTexParameteriv(GL_TEXTURE_2D, GL_TEXTURE_CROP_RECT_OES, crop);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    }

    return NO_ERROR;
}

static float property_get_float(const char* key, float defaultValue) {
    char buf[PROPERTY_VALUE_MAX] = {'\0',};

    if (property_get(key, buf, "") > 0) {
        return atof(buf);
    }
    return defaultValue;
}
void TrackView::initConfig ()
{
    mW = 1581;
    mL = 2726;
    mD = 300;
    mH = 900;
    mOA = 80;
    mIA = 42;
    mTL = 5000;

    mCA = 20;
    mRate = 700;
    mLw = 50.0f;
    mW = property_get_float(REAR_AXLE_LENGTH,mW);
    mL = property_get_float(WHEEL_BASE,mL);
    mD = property_get_float(DISTANCE_CAMERA_REAR_AXLE,mD);
	mH = property_get_float(CAMERA_LOCATION,mH);
	mOA = property_get_float(CAMERA_ANGLE,mOA);
	mIA = property_get_float(ANGLE_CAMERA_PLANE,mIA);
	mCA = property_get_float(STEERING_ANGLE,mCA);
	mTL = property_get_float(TRACK_LENGTH,mTL);
    ALOGD("mW=%1.3f, mL=%1.3f, mD=%1.3f, mH=%1.3f, mOA=%1.3f, mIA=%1.3f, mCA=%1.3f, mTL=%1.3f",mW,mL,mD,mH,mOA,mIA,mCA,mTL);
	mSteeringValid = 0;
}

void TrackView:: updateViewParams()
{

    float na = (90 - mIA - mOA/2)*(PI / 180.0f);
    mRate = mH/(float)cos(na) * sin(mOA/2*(PI / 180.0f))*2;

    float CA = mCA*(float) (PI / 180.0f);
    float rm;
    if(CA==0) {
        rm = 0;
    }else{
        rm = mL/(float)tan(CA);
    }
    float IA = mIA*(float) (PI / 180.0f);
    eyeX = rm/mRate;
    eyeY = mD/mRate;
    eyeZ = mH/mRate;

    centerX = eyeX;
    centerY = eyeZ/(float)tan(IA) + eyeY;
    centerZ = 0.0f;

    upX = 0.0f;
    upY = 0.0f;
    upZ = 1.0f;

    ALOGD("mCA=%2.3f",mCA);
    ALOGD("eyeX=%1.3f, eyeY=%1.3f, eyeZ=%1.3f",eyeX,eyeY,eyeZ);
    ALOGD("centerX=%1.3f, centerY=%1.3f, centerZ=%1.3f",centerX,centerY,centerZ);
    ALOGD("upX=%1.3f, upY=%1.3f, upZ=%1.3f",upX,upY,upZ);
    //upY = 0.0f;

    mNear = mH/(float)cos(na) * cos(mOA/2*(PI / 180.0f))/mRate;
    mFar = 10.0f;
    ALOGD("mNear=%1.3f, mFar=%2.3f",mNear,mFar);
}

void TrackView:: updateLineVertices ()
{
    float na = (90 - mIA - mOA/2)*(PI / 180.0f);
    mRate = mH/(float)cos(na) * sin(mOA/2*(PI / 180.0f))*2;
    ALOGD("mRate=%f",mRate);

    //float Xos, Yos, Xoe, Yoe;
    //float Xis, Yis, Xie, Yie;
    float rm; //Radius for the track of center of back axle.
    float A;
    if(mCA==0) {
        rm = 0.0f;
        A = mTL/mRate;
    }else {
        float CA = mCA*(float) (PI / 180.0f);
        rm = mL/(float)tan(CA);
        if(mCA<0){
            mW=mW*(-1.0f);
            mLw = mLw*(-1.0f);
        }
        A = mTL/rm;
    }

    int i;
    float ro1 = (rm+mW/2)/mRate;
    float ro2 = (rm+mW/2 + mLw)/mRate;
    for(i=0; i<N+1; i++) {
        if(mCA==0) {
            mVerticesR[i*6] = ro1;
            mVerticesR[i*6 + 1] = (A/N)*i;
            mVerticesR[i*6 + 2] = 0.0f;
            mVerticesR[i*6 + 3] = ro2;
            mVerticesR[i*6 + 4] = (A/N)*i;
            mVerticesR[i*6 + 5] = 0.0f;
        } else {
            mVerticesR[i*6] = (float)cos(A/N*i)*ro1;
            mVerticesR[i*6 + 1] = (float)sin(A/N*i)*ro1;
            mVerticesR[i*6 + 2] = 0.0f;
            mVerticesR[i*6 + 3] = (float)cos(A/N*i)*ro2;
            mVerticesR[i*6 + 4] = (float)sin(A/N*i)*ro2;
            mVerticesR[i*6 + 5] = 0.0f;
        }
    }

    float ri1 = (rm-mW/2)/mRate;
    float ri2 = (rm-mW/2 - mLw)/mRate;
    for(i=0; i<N+1; i++) {
        if(mCA==0) {
            mVerticesL[i*6] = ri2;
            mVerticesL[i*6 + 1] = (A/N)*i;
            mVerticesL[i*6 + 2] = 0.0f;
            mVerticesL[i*6 + 3] = ri1;
            mVerticesL[i*6 + 4] = (A/N)*i;
            mVerticesL[i*6 + 5] = 0.0f;
        } else {
            mVerticesL[i*6] = (float)cos(A/N*i)*ri2;
            mVerticesL[i*6 + 1] = (float)sin(A/N*i)*ri2;
            mVerticesL[i*6 + 2] = 0.0f;
            mVerticesL[i*6 + 3] = (float)cos(A/N*i)*ri1;
            mVerticesL[i*6 + 4] = (float)sin(A/N*i)*ri1;
            mVerticesL[i*6 + 5] = 0.0f;
        }
    }

    if(mCA==0) {
        mVerticesB[0] = ri2 ;
        mVerticesB[1] = A;
        mVerticesB[2] = 0.0f;
    
        mVerticesB[3] = ro2;
        mVerticesB[4] = A;
        mVerticesB[5] = 0.0f;

        mVerticesB[6] = ri2;
        mVerticesB[7] = A+mLw/mRate;
        mVerticesB[8] = 0.0f;

        mVerticesB[9] = ro2;
        mVerticesB[10] = A+mLw/mRate;
        mVerticesB[11] = 0.0f;
    } else {
        mVerticesB[0] = (float)cos(A)*ri2 ;
        mVerticesB[1] = (float)sin(A)*ri2;
        mVerticesB[2] = 0.0f;
    
        mVerticesB[3] = (float)cos(A)*ro2;
        mVerticesB[4] = (float)sin(A)*ro2;
        mVerticesB[5] = 0.0f;

        mVerticesB[6] = (float)cos(A)*ri2 - (float)sin(atan(mVerticesB[0]/mVerticesB[1]))*mLw/mRate;
        mVerticesB[7] = (float)sin(A)*ri2 + (float)cos(atan(mVerticesB[0]/mVerticesB[1]))*mLw/mRate;
        mVerticesB[8] = 0.0f;

        mVerticesB[9] = (float)cos(A)*ro2 - (float)sin(atan(mVerticesB[0]/mVerticesB[1]))*mLw/mRate;
        mVerticesB[10] = (float)sin(A)*ro2 + (float)cos(atan(mVerticesB[0]/mVerticesB[1]))*mLw/mRate;
        mVerticesB[11] = 0.0f;
    }
    ALOGD("Os1(%2.5f, %2.5f, %2.5f)",mVerticesL[0],mVerticesL[1], mVerticesL[2]);
    ALOGD("Os2(%2.5f, %2.5f, %2.5f)",mVerticesL[3],mVerticesL[4], mVerticesL[5]);
    ALOGD("Oe1(%2.5f, %2.5f, %2.5f)",mVerticesL[N],mVerticesL[N+1], mVerticesL[N+2]);
    ALOGD("Oe2(%2.5f, %2.5f, %2.5f)",mVerticesL[N+3],mVerticesL[N+4], mVerticesL[N+5]);
    
    ALOGD(" Is1(%2.5f, %2.5f, %2.5f)",mVerticesR[0],mVerticesR[1], mVerticesR[2]);
    ALOGD(" Is2(%2.5f, %2.5f, %2.5f)",mVerticesR[3],mVerticesR[4], mVerticesR[5]);

    ALOGD(" Ie1(%2.5f, %2.5f, %2.5f)",mVerticesR[N],mVerticesR[N+1], mVerticesR[N+2]);
    ALOGD(" Ie2(%2.5f, %2.5f, %2.5f)",mVerticesR[N+3],mVerticesR[N+4], mVerticesR[N+5]);
 
}

void TrackView::update(void* data)
{
    Mutex::Autolock _l(mLock);
    SteeringData* steeringData = (SteeringData*) data;
    if(mSteeringValid != steeringData->valid){
        ALOGD("update steeringData->valid=%d,mSteeringValid=%d",steeringData->valid,mSteeringValid);
    }else if(abs(mCA-steeringData->ca)<0.2f) {
        return;
    }
    mCA = steeringData->ca;
    mSteeringValid = steeringData->valid;
    ALOGD("update mCA=%2.3f,mSteeringValid=%d",mCA,mSteeringValid);
    mSurfaceDirty = true;
    mCondition.broadcast();
}



static const char* vertexSourceOl =
        "attribute vec4 vPosition;"
        "attribute vec2 inputTextureCoordinate;"
        "varying vec2 textureCoordinate;"
        "void main()"
        "{"
            "gl_Position = vPosition;"
            "textureCoordinate = inputTextureCoordinate;"
        "}";
 static const char* fragmentSourceOl =
        "precision mediump float;"
        "varying vec2 textureCoordinate;\n"
        "uniform sampler2D s_texture;\n"
        "uniform vec4 u_modulation;\n"
        "void main() {"
        "  gl_FragColor = texture2D( s_texture, textureCoordinate );\n"
        //"  gl_FragColor *= u_modulation;\n"
        "}";
bool TrackView::threadLoop_l ()
{
const char* vertexSource = 
"attribute vec4 vPosition;\n"
"uniform mat4 vMVPMatrix;\n"
"void main()\n"
"{\n"
"gl_Position = vMVPMatrix*vPosition;\n"
"}\n";

const char* fragmentSource = 
"precision mediump float;\n"
"uniform vec4 vColor;\n"
"void main() {\n"
"gl_FragColor = vColor;\n"
"}\n";
/*const char* vertexShaderSource =
"attribute vec4 vPosition;\n"
"uniform mat4 vMVPMatrix;\n"
"void main()\n"
"{\n"
"gl_Position = vMVPMatrix*vec4(vPosition.x, vPosition.y, vPosition.z, 1.0f);\n"
"}\n";

const char* fragmentShaderSource =
"precision mediump float;\n"
"uniform vec4 vColor;\n"
"void main() {\n"
"gl_FragColor = vec4(vColor.r, vColor.g, vColor.g, vColor.a);\n"
"}\n";*/

    const GLint version_attribs[] = {
        EGL_CONTEXT_CLIENT_VERSION, 2,
        EGL_NONE
    };
    eglMakeCurrent(mDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    eglDestroyContext(mDisplay, mContext);
    checkGlError(__LINE__);
    mContext = eglCreateContext(mDisplay, mConfig, EGL_NO_CONTEXT, version_attribs);
    checkGlError(__LINE__);
    if (eglMakeCurrent(mDisplay, mSurface, mSurface, mContext) == EGL_FALSE) {
        ALOGE("%s eglMakeCurrent 2.0 error", __FUNCTION__);
        requestExit();
        return false;
    }

    mOverlayProgram = createProgram(vertexSourceOl, fragmentSourceOl);
    mOverlayPositionHandle = glGetAttribLocation(mOverlayProgram, "vPosition");
    mOverlayTextureCoordHandle = glGetAttribLocation (mOverlayProgram, "inputTextureCoordinate");
    
    mProgram = createProgram(vertexSource, fragmentSource);
    if(mProgram==0){
        ALOGE("%s createProgram Failed!", __FUNCTION__);
        requestExit();
        return false;
    }
    mPositionHandle = glGetAttribLocation(mProgram, "vPosition");
    checkGlError(__LINE__);
    mMVPMatrixHandle = glGetUniformLocation(mProgram, "vMVPMatrix");
    mColorHandle = glGetUniformLocation(mProgram, "vColor");



    mAssets.addDefaultAssets();
    if(initTexture(&mOverlayTexName, mAssets, "images/pas/static_track.png", true)!=NO_ERROR) {
        ALOGD("init static texture failed");
        return true;
    }
    mSurfaceDirty = true;
    while(!exitPending())
    {
        {
            Mutex::Autolock _l(mLock);
            while(!mSurfaceDirty&&!exitPending ())
            {
                if(mCondition.waitRelative(mLock, milliseconds(100))==NO_ERROR)
                    break;
            }
            mSurfaceDirty = false;
            if(exitPending ()) {
                break;
            }
            updateViewParams();
            updateLineVertices();
        }
        if(exitPending ()){
            break;
        }
    int fd;
    fd = open(BACKSERVICE_RVC_STATUS_FILE, O_RDWR | O_CLOEXEC);
    if(fd < 0) {
        ALOGE("could not open backservice_rvc_status %s\n",strerror(errno));
        return -1;
    }
    char rvc[2];
    read(fd, &rvc, 1);	
    ALOGD("rvc=%s",rvc);
    if(!strcmp(rvc, "1")){
        drawTrack();
    }
	close(fd);
    }
    glDeleteProgram(mProgram);
    glDeleteProgram(mOverlayProgram);
    glDeleteTextures(1, &mOverlayTexName);
    
    return true;
}

void TrackView::drawTrack()
{
    ALOGD("drawTrack() -S");

    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    //eglSwapBuffers(mDisplay, mSurface);

    drawStaticTrack();
    drawDynamicTrack();


    eglSwapBuffers(mDisplay, mSurface);
    checkGlError(__LINE__);
    ALOGD("drawTrack() -E");
}

static const GLfloat srcVertices1[] = {
0.0f, 1.0f,
1.0f, 1.0f,
1.0f, 0.0f,
0.0f, 0.0f,
};

static const GLfloat vertices1[] = {
-1.0f, 0.0f,
1.0f, 0.0f,
1.0f, 1.0f,
-1.0f, 1.0f
};
static const GLushort drawOrder[] = { 0, 1, 2, 0, 2, 3 }; // order to draw vertices
void TrackView::drawStaticTrack()
{
    //glViewport(mX, mY, mWidth, mHeight);
    glViewport(0, 0, mWidth, mHeight);
    glUseProgram(mOverlayProgram);

    glEnable(GL_BLEND);
    glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, mOverlayTexName);

    glEnableVertexAttribArray(mOverlayPositionHandle);
    glVertexAttribPointer(mOverlayPositionHandle, 2, GL_FLOAT, GL_FALSE, 0, vertices1);
    glEnableVertexAttribArray(mOverlayTextureCoordHandle);
    glVertexAttribPointer(mOverlayTextureCoordHandle, 2, GL_FLOAT, GL_FALSE, 0, srcVertices1);

    glDrawElements(GL_TRIANGLES, sizeof(drawOrder)/sizeof(drawOrder[0]), GL_UNSIGNED_SHORT, drawOrder);
    glFinish();

    glDisableVertexAttribArray(mOverlayPositionHandle);
    glDisableVertexAttribArray(mOverlayTextureCoordHandle);
}

void TrackView::drawDynamicTrack()
{
    GLfloat mvpMatrix[]={
        1.0f, 0.0f, 0.0f, 0.0f,
        0.0f, 1.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 1.0f, 0.0f,
        0.0f, 0.0f, 0.0f, 1.0f
    };
    GLfloat color[]={1.0f, 1.0f, 1.0f, 0.5f};
    //testUpdateParams();

    //glViewport(mX, mY, mWidth, mHeight);
    //glViewport(0, 0, mWidth, mHeight);
    glUseProgram(mProgram);

    perspectiveM(mvpMatrix, mOA, 2.0f, mNear, mFar);

    lookAtM(mvpMatrix, eyeX, eyeY, eyeZ,
        centerX, centerY, centerZ,
        upX, upY, upZ);


    glUniformMatrix4fv(mMVPMatrixHandle, 1, false, mvpMatrix);

    glEnable(GL_BLEND);
    glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);

    ALOGD("start draw L");
    if(mSteeringValid){
        drawLine(mVerticesL, color,  (N+1)*2);
    }else {
        drawLine(NULL, color,  (N+1)*2);
    }

    ALOGD("start draw R");
    if(mSteeringValid){
        drawLine(mVerticesR, color,  (N+1)*2);
    }else {
        drawLine(NULL, color,  (N+1)*2);
    }    
    ALOGD("start draw B");
	if(mSteeringValid){
        drawLine(mVerticesB, color, 4);
    }else {
        drawLine(NULL, color, 4);
    }    
    glFinish();
    checkGlError(__LINE__);
}

void TrackView::drawLine(const void* pointer, const GLfloat* color, int num)
{
    glEnableVertexAttribArray(mPositionHandle);
    checkGlError(__LINE__);
    glVertexAttribPointer(mPositionHandle, 3, GL_FLOAT, false, 0, pointer);
    checkGlError(__LINE__);
    glUniform4f(mColorHandle, color[0], color[1], color[2], color[3]);
    checkGlError(__LINE__);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, num);
    checkGlError(__LINE__);
    glDisableVertexAttribArray(mPositionHandle);
    checkGlError(__LINE__);
}

}
