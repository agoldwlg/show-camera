/*
* Description:
* Autor:
*/
#ifndef _VIEW_MODULE_H
#define _VIEW_MODULE_H

#include <utils/Mutex.h>
#include <utils/RefBase.h>
#include <sys/types.h>

#include "CameraView.h"
#include "RadarView.h"

namespace android {

class ViewModule: public RefBase
{
private:
    sp<CameraView> mCameraView;
    sp<RadarView> mRadarView;
    bool mIsDisplaying;
    Mutex mLock;
public:
    ViewModule ();
    virtual ~ ViewModule ();
    bool processEvent(int event, void* p_data);
    void display();
    void dismiss();
    bool isDisplaying();
};
};
#endif
