
#define LOG_NDEBUG 0
#define LOG_TAG "PAS_CameraView"

#include <stdint.h>
#include <sys/types.h>
#include <utils/Log.h>
#include <binder/IServiceManager.h>
#include <binder/IBinder.h>


#include <SkBitmap.h>
#include <SkStream.h>
#include <SkImageDecoder.h>

#include "CameraView.h"

namespace android {

CameraView::CameraView (bool withTrack):ViewBase("cameraview")
{
    if(withTrack) {
        mTrackView = new TrackView();
        mTrackView->setLayer(0x3D472);
    }
    mAssets.addDefaultAssets();
	mCameraDefaultTexId = 0;
    mFrameAvailable = false;
}

CameraView::~CameraView ()
{
    mStartFlag = false;
    mCameraDefaultTexId = 0;
    if(mTrackView!=NULL)
        mTrackView.clear();
}

void CameraView::update(void* data) {
    if(mTrackView!=NULL) {
        mTrackView->update(data);
    }
}

bool CameraView:: startCamera (){
    sp<IServiceManager> sm = defaultServiceManager();
    sp<IBinder> binder = NULL;
    for(;;) {
        binder = sm->checkService(String16("media.camera"));
        if(binder!=0) break;
        ALOGW("CameraService not published, waiting ?");
        usleep(100000);
    }

    String16 name("cameraview");
    sp<Camera> camera = Camera::connect(0, name, Camera::USE_CALLING_UID, Camera::USE_CALLING_PID);
    if(camera==NULL) {
        ALOGE("Fail to connect to camera service");
        return false;
    }
    mCamera = camera;
    //mCamera ->setListener(this);
    if(mCamera ->setPreviewTarget(mProducer)!=NO_ERROR){
        ALOGE("setPreviewTexture failed!");
        return false;
    }
    if(mCamera->startPreview()!=NO_ERROR){
        ALOGE("startPreview failed");
        return false;
    }
    mStartFlag = true;
    ALOGD("start camera success!");
    return true;
}

bool CameraView:: stopCamera (){
    if(mCamera!=NULL) {
        mCamera->stopPreview();
        mCamera->setPreviewTarget(NULL);
        mCamera->disconnect();
        mCamera.clear();
        ALOGD("stop camera success!");
    }
    mCameraDefaultTexId = 0;
	mStartFlag = false;
    return true;
}

void CameraView:: initTexture (){
    glGenTextures(1, &mTexId);
    glBindTexture(GL_TEXTURE_EXTERNAL_OES, mTexId);
    glTexParameterf(GL_TEXTURE_EXTERNAL_OES, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_EXTERNAL_OES, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_EXTERNAL_OES, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_EXTERNAL_OES, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    BufferQueue::createBufferQueue(&mProducer, &mConsumer);
    mSurfaceTexture = new GLConsumer(mConsumer, mTexId, GL_TEXTURE_EXTERNAL_OES, true, true);
    mSurfaceTexture->setFrameAvailableListener(this);
}

bool CameraView:: startCameraErrorDisplayPicture (){
 // clear screen

    glEnable(GL_TEXTURE_2D);
    glTexEnvx(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

    const Rect updateRect(0, 640, 960, 640);
    glScissor(0, 640,960, 640);
    // Blend state
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glTexEnvx(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    do{
    glEnable(GL_SCISSOR_TEST);
    glEnable(GL_BLEND);
    glBindTexture(GL_TEXTURE_2D, mCameraDefaultTexId);
    glDrawTexiOES(0,640,0,960,640);
    eglSwapBuffers(mDisplay, mSurface);
    usleep(300);
    }while(!exitPending());
    mCameraDefaultTexId = 0;
    glDeleteTextures(1, &mCameraDefaultTexId);
	if(mCamera!=NULL) {
        mCamera->stopPreview();
        mCamera->setPreviewTarget(NULL);
        mCamera->disconnect();
        mCamera.clear();
    }
    return false;    
}

status_t CameraView::initCameraDefaultTexture()
{
    int x,y,w,h;
    GLuint* textureId = &(mCameraDefaultTexId);
    const char* name="ServiceRearVisionCamera.png";
    
    if(*textureId != 0) {
        ALOGD("textureId!=0 returen,name=%s",name);
        return NO_ERROR;
    }
	ALOGD("initCameraDefaultTexture name=%s", name);
	char path[50] = "images/pas/";
    strcat(path, name);
    ALOGD("image=%s", path);
	Asset* asset = mAssets.open(path, Asset::ACCESS_BUFFER);
    if (asset == NULL) {
        ALOGD("initCameraDefaultTexture asset == NULL name=%s", path);
        return NO_INIT;
	}
    SkBitmap bitmap;
    SkImageDecoder::DecodeMemory(asset->getBuffer(false), asset->getLength(),
            &bitmap, kUnknown_SkColorType, SkImageDecoder::kDecodePixels_Mode);
    asset->close();
    delete asset;	
	w = bitmap.width();
    h = bitmap.height();
	x = 0;
	y = 640;
	const void* p = bitmap.getPixels();
	ALOGD("initCameraDefaultTexture name=%s,w=%d,h=%d,x=%d,y=%d,bitmap.colorType()=%d", name,w,h,x,y,bitmap.colorType());
	GLint crop[4] = { 0, y, w, -h };
	glGenTextures(1, textureId);
	glBindTexture(GL_TEXTURE_2D, *textureId);
    switch (bitmap.colorType()) {
        case kAlpha_8_SkColorType:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_ALPHA, w, h, 0, GL_ALPHA,
                    GL_UNSIGNED_BYTE, p);
            break;
        case kARGB_4444_SkColorType:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA,
                    GL_UNSIGNED_SHORT_4_4_4_4, p);
            break;
        case kN32_SkColorType:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA,
                    GL_UNSIGNED_BYTE, p);
            break;
        case kRGB_565_SkColorType:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, w, h, 0, GL_RGB,
                    GL_UNSIGNED_SHORT_5_6_5, p);
            break;
        default:
            break;
    }
	glTexParameteriv(GL_TEXTURE_2D, GL_TEXTURE_CROP_RECT_OES, crop);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    return NO_ERROR;
}

static const char *vertexSource =
        "attribute vec4 vPosition;"
        "attribute vec2 inputTextureCoordinate;"
        "varying vec2 textureCoordinate;"
        "void main()"
        "{"
            "gl_Position = vPosition;"
            "textureCoordinate = inputTextureCoordinate;"
        "}";

static const char *fragmentSource =
        "#extension GL_OES_EGL_image_external : require\n"
        "precision mediump float;"
        "varying vec2 textureCoordinate;\n"
        "uniform samplerExternalOES s_texture;\n"
        "uniform vec4 u_modulation;\n"
        "void main() {"
        "  gl_FragColor = texture2D( s_texture, textureCoordinate );\n"
       // "  gl_FragColor *= u_modulation;\n"
        "}";


static const GLfloat vertices1[] = {
-1.0f, 0.0f,
1.0f, 0.0f,
1.0f, 1.0f,
-1.0f, 1.0f
};

static const GLfloat srcVertices1[] = {
0.0f, 1.0f,
1.0f, 1.0f,
1.0f, 0.0f,
0.0f, 0.0f
};

static const GLushort drawOrder[] = {0, 1, 2, 0, 2, 3};


bool CameraView::threadLoop_l ()
{
    const GLint version_attribs[] = {
        EGL_CONTEXT_CLIENT_VERSION, 2,
        EGL_NONE
    };
    eglMakeCurrent(mDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    eglDestroyContext(mDisplay, mContext);

    mContext = eglCreateContext(mDisplay, mConfig, EGL_NO_CONTEXT, version_attribs);
    if (eglMakeCurrent(mDisplay, mSurface, mSurface, mContext) == EGL_FALSE) {
        ALOGE("%s eglMakeCurrent 2.0 error", __FUNCTION__);
        return false;
    }


    GLuint mProgram = createProgram(vertexSource, fragmentSource);
    GLuint mPositionHandle = glGetAttribLocation(mProgram, "vPosition");
    GLuint mTextureCoordHandle = glGetAttribLocation (mProgram, "inputTextureCoordinate");

    initTexture();

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    eglSwapBuffers(mDisplay, mSurface);

    bool surfaceDirty = false;
    float mtx[16];
    while(!exitPending())
    {
        {
            Mutex::Autolock _l(mLock);
            while(!mFrameAvailable&&!exitPending())
            {
                if(mCamera==NULL) {
                    if(!startCamera()) {
                        eglMakeCurrent(mDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
                        eglDestroyContext(mDisplay, mContext);
                        glDeleteProgram(mProgram);
                        glDeleteTextures(1, &mTexId);
                        mSurfaceTexture->abandon();
                        mSurfaceTexture.clear();
                        mContext = eglCreateContext(mDisplay, mConfig, NULL, NULL);
                        if (eglMakeCurrent(mDisplay, mSurface, mSurface, mContext) == EGL_FALSE){
                            return false;
                        }                        
                        initCameraDefaultTexture();
                        startCameraErrorDisplayPicture();
                        ALOGE("open camera failed!");
                        return false;
                    }
                }
                if(mCondition.waitRelative(mLock, milliseconds(100))==NO_ERROR)
                    break;
            }
            if(exitPending()){
                break;
            }
			if(mStartFlag){
				usleep(300000);
                ALOGE("open camera usleep(300000)");
				mStartFlag = false;
				}
            status_t err = mSurfaceTexture->updateTexImage();
            if(err==INVALID_OPERATION){
                ALOGE("Unable to update texture contents!");
                surfaceDirty = false;
            }else if(err<0){
                ALOGE("Error during updateTexImage!");
                surfaceDirty = false;
            }else{
                surfaceDirty = true;
                mSurfaceTexture->getTransformMatrix(mtx);
            }
            mFrameAvailable = false;
        }

        if(surfaceDirty) {
            if(mTrackView!=NULL && !mTrackView->isDisplaying()) {
                mTrackView->display();
            }

            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            
            glUseProgram(mProgram);

            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_EXTERNAL_OES, mTexId);

            // Enable a handle to the triangle vertices
            glEnableVertexAttribArray(mPositionHandle);
            // Prepare the <insert shape here> coordinate data
            glVertexAttribPointer(mPositionHandle, 2, GL_FLOAT, GL_FALSE, 0, vertices1);

            glEnableVertexAttribArray(mTextureCoordHandle);
            glVertexAttribPointer(mTextureCoordHandle, 2, GL_FLOAT, GL_FALSE, 0, srcVertices1);

            glDrawElements(GL_TRIANGLES, sizeof(drawOrder)/sizeof(drawOrder[0]), GL_UNSIGNED_SHORT, drawOrder);

            // Disable vertex array
            glDisableVertexAttribArray(mPositionHandle);
            glDisableVertexAttribArray(mTextureCoordHandle);

            eglSwapBuffers(mDisplay, mSurface);

            surfaceDirty = false;
        }
    }
    if(mTrackView!=NULL && mTrackView->isDisplaying()) {
        mTrackView->dismiss();
    }

    stopCamera();
    mSurfaceTexture->abandon();
    mSurfaceTexture.clear();

    glDeleteProgram(mProgram);
    glDeleteTextures(1, &mTexId);
    glDeleteTextures(1, &mCameraDefaultTexId);

    return true;
}

void CameraView::onFrameAvailable(const BufferItem&)
{
    Mutex::Autolock _l(mLock);
    mFrameAvailable = true;
    mCondition.broadcast();
}

}
