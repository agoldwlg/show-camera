
#define LOG_NDEBUG 0
#define LOG_TAG "PAS_ViewBase"

#include <stdint.h>
#include <sys/types.h>
//#include <signal.h>
//#include <time.h>

#include <cutils/properties.h>

//#include <binder/IPCThreadState.h>
#include <utils/Atomic.h>
#include <utils/Errors.h>
#include <utils/Log.h>

#include <ui/PixelFormat.h>
#include <ui/Rect.h>
#include <ui/Region.h>
#include <ui/DisplayInfo.h>

#include <gui/ISurfaceComposer.h>
#include <gui/Surface.h>
#include <gui/SurfaceComposerClient.h>

// TODO: Fix Skia.
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"
#include <SkBitmap.h>
#include <SkStream.h>
#include <SkImageDecoder.h>
#pragma GCC diagnostic pop




#include "ViewBase.h"


namespace android {

ViewBase::ViewBase(const char* name):Thread(false) {
    mSession = new SurfaceComposerClient();
    mName = name?strdup(name):NULL;
    mX = 0;
    mY = 0;
    mLayer = 0x40100001;
    mUseAlpha = false;
}

ViewBase::~ViewBase(){
    mSession.clear();
}

void ViewBase::onFirstRef (){
    mSession->linkToComposerDeath(this);
}

void ViewBase::binderDied(const wp<IBinder>&) {
    //kill(getpid(), SIGKILL);
    requestExit();
}

void ViewBase:: display () {
    if(isRunning()) return;
    ALOGD("start display %s", mName);
    run(mName, PRIORITY_DISPLAY);
}

void ViewBase:: dismiss (){
    if(!isRunning()) return;
    ALOGD("request dismiss %s", mName);
    requestExitAndWait();
}

bool ViewBase::isDisplaying() {
    return isRunning();
}

void ViewBase::setLayout(int x, int y, int width, int height)
{
    mX = x;
    mY = y;
    mWidth = width;
    mHeight = height;
}
void ViewBase::setLayer(uint32_t layer) {
    mLayer = layer;
}
void ViewBase::setUseAlpha(bool alpha) {
    mUseAlpha = alpha;
}
status_t ViewBase ::readyToRun() {
    sp<IBinder> dtoken(SurfaceComposerClient::getBuiltInDisplay(
            ISurfaceComposer::eDisplayIdMain));
    DisplayInfo dinfo;
    status_t status = SurfaceComposerClient::getDisplayInfo(dtoken, &dinfo);
    if (status)
        return -1;

    sp<SurfaceControl> control = mSession->createSurface(String8(mName),
            dinfo.w, dinfo.h, PIXEL_FORMAT_RGB_565);

    SurfaceComposerClient::openGlobalTransaction();
    control->setLayer(mLayer);
    SurfaceComposerClient::closeGlobalTransaction();


    sp<Surface> s = control->getSurface();

    // initialize opengl and egl
    const EGLint attribs[] = {
            EGL_RED_SIZE,   8,
            EGL_GREEN_SIZE, 8,
            EGL_BLUE_SIZE,  8,
            EGL_ALPHA_SIZE, 8,
            EGL_DEPTH_SIZE, 0,
            EGL_NONE
    };
    EGLint w, h;
    EGLint numConfigs;
    EGLConfig config;
    EGLSurface surface;
    EGLContext context;

    EGLDisplay display = eglGetDisplay(EGL_DEFAULT_DISPLAY);

    eglInitialize(display, 0, 0);
    eglChooseConfig(display, attribs, &config, 1, &numConfigs);
    surface = eglCreateWindowSurface(display, config, s.get(), NULL);
    context = eglCreateContext(display, config, NULL, NULL);

    eglQuerySurface(display, surface, EGL_WIDTH, &w);
    eglQuerySurface(display, surface, EGL_HEIGHT, &h);

    if (eglMakeCurrent(display, surface, surface, context) == EGL_FALSE)
        return NO_INIT;

    mDisplay = display;
    mContext = context;
    mSurface = surface;
    mConfig = config;
    mWidth = w;
    mHeight = h;
    mFlingerSurfaceControl = control;
    mFlingerSurface = s;

    return NO_ERROR;
}

bool ViewBase::threadLoop()
{
    ALOGD("threadLoop %s", mName);
    bool r = threadLoop_l();

    
    eglMakeCurrent(mDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    eglDestroyContext(mDisplay, mContext);
    eglDestroySurface(mDisplay, mSurface);
    mFlingerSurface.clear();
    mFlingerSurfaceControl.clear();
    eglTerminate(mDisplay);

    return r;
}

void ViewBase::checkGlError(int line) {
    int error = glGetError();
    if (error != GL_NO_ERROR) {
        ALOGE("GL error @line %d = 0x%x", line, error);
    }
}

GLuint ViewBase::loadShader(int type, const char* source)
{
    GLuint iShader = glCreateShader(type);
    checkGlError(__LINE__);
    GLint compiled;
    if(iShader!=0) {
        glShaderSource(iShader, 1, &source, NULL);
        checkGlError(__LINE__);
        glCompileShader(iShader);
        checkGlError(__LINE__);
        glGetShaderiv(iShader, GL_COMPILE_STATUS, &compiled);
        checkGlError(__LINE__);
        if(compiled==0){
            glDeleteShader(iShader);
            iShader = 0;
        }
    }
    return iShader;
}

GLuint ViewBase::createProgram(const char* vSrc, const char* fSrc)
{
    GLuint iVertexShader = loadShader(GL_VERTEX_SHADER, vSrc);
    GLuint iFragmentShader = loadShader(GL_FRAGMENT_SHADER, fSrc);
    GLuint program = glCreateProgram();
    checkGlError(__LINE__);
    GLint linkStatus;
    if(program!=0){
        ALOGD("createProgram() program=%d, Vshader=%d, Fshader=%d", program, iVertexShader, iFragmentShader);
        glAttachShader(program, iVertexShader);
        checkGlError(__LINE__);
        glAttachShader(program, iFragmentShader);
        checkGlError(__LINE__);
        glLinkProgram(program);
        checkGlError(__LINE__);
        glDeleteShader(iVertexShader);
        checkGlError(__LINE__);
        glDeleteShader(iFragmentShader);
        checkGlError(__LINE__);
        glGetProgramiv(program, GL_LINK_STATUS, &linkStatus);
        checkGlError(__LINE__);
        if(linkStatus!=GL_TRUE) {
            glDeleteProgram(program);
            program = 0;
        }
    }
    return program;
}

}

