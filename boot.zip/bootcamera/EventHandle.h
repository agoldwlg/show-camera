/*
* Description:
* Autor:
*/
#ifndef _EVENT_HANDLE_H
#define _EVENT_HANDLE_H

#include <utils/RefBase.h>
#include <sys/types.h>
#include <utils/Condition.h>
#include <utils/Mutex.h>
#include <utils/Thread.h>
#include "ViewModule.h"
#include "Event.h"

namespace android {

class EventHandle : public Thread, public virtual RefBase
{
private:
    State mAccOn;
    State mReverseOn;
    State mRVCOn;
    bool mStatusChanged;
    bool mForceDisplay;
	char mForceDisplayProp[10];
    Mutex mStatusLock;
    Condition mCondition;
    sp<ViewModule> mView;
public:
    EventHandle();
    virtual ~EventHandle();
    bool processEvent(int event, void* p_data);
private:
    virtual bool threadLoop();
    virtual void onFirstRef();
    bool checkForceDisplay();
    bool writePasDisplayStatus(const char *filename);
    void handleStatusEvent(int event, State state);
};

};
#endif
