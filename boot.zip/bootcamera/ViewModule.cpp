
#include "ViewModule.h"
#include "Event.h"

#define SCREEN_WIDTH 1080
#define SCREEN_HEIGHT 1920
namespace android {
ViewModule::ViewModule () {
    mIsDisplaying = false;

    int w = SCREEN_WIDTH;
    int h = SCREEN_HEIGHT;
    mCameraView = new CameraView(true);
    mCameraView->setLayout(0, h/2, w, h/2);
    mRadarView = new RadarView();
    mCameraView->setLayer(0x3D471);
    mRadarView->setLayer(0x3D473);
    mRadarView->setLayout(0, 0, w, h/2);
}
ViewModule::~ViewModule () {
    mCameraView.clear();
    mRadarView.clear();
}

void ViewModule::display() {
    Mutex::Autolock _l(mLock);
    mCameraView->display();
    mRadarView->display();
    mIsDisplaying = true;
}

void ViewModule::dismiss() {
    Mutex::Autolock _l(mLock);
    mCameraView->dismiss();
    mRadarView->dismiss();
    mIsDisplaying = false;
}

bool ViewModule::isDisplaying() {
    Mutex::Autolock _l(mLock);
    return mIsDisplaying;
}

bool ViewModule::processEvent(int event, void* p_data) {
    switch(event) {
    case EVENT_STEERING:
        mCameraView->update(p_data);
        return true;
    case EVENT_RADAR:
        mRadarView->update(p_data);
        return true;
    }
    return false;
}

}

