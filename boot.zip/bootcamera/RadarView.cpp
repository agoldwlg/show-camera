
#define LOG_NDEBUG 0
#define LOG_TAG "PAS_RadarView"

#include <stdint.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/ioctl.h>

#include <utils/Log.h>
//#include <utils/String16.h>

#include <SkBitmap.h>
#include <SkStream.h>
#include <SkImageDecoder.h>

#include <cutils/properties.h>

#include "Event.h"
#include "RadarView.h"

static SegmentInfo mSegInfo[] = {
    {0,0,0,0, {"car.png", NULL, NULL,NULL}, {0, 0, 0}, 0},
    {0,0,0,0, {"back_BG.png", NULL, NULL,NULL}, {0, 0, 0}, 0},
    {0,0,0,0, {"left1_1.png", "left1_2.png","left1_3.png" ,NULL}, {0, 0, 0}, -1},
    {0,0,0,0, {"left2_1.png", "left2_2.png", "left2_3.png","left2_4.png"}, {0, 0, 0}, -1},
    {0,0,0,0, {"right1_1.png", "right1_2.png","right1_3.png" ,NULL}, {0, 0, 0}, -1},
    {0,0,0,0, {"right2_1.png", "right2_2.png", "right2_3.png","right2_4.png"}, {0, 0, 0}, -1}
};

static NoticeSegmentInfo mNoticeSegmentInfo[] = {
    {"attention.png",0},
    {"Radar_System_Fault.png",0},
    {"Radar_Fault.png",0}
};

static const char RADAR_PATH[] = "/dev/egar_dev_audio";

namespace android {

RadarView::RadarView():ViewBase("radarview")
{
    mAssets.addDefaultAssets();
	mRadarSysStatus = 0;
    mRadarStatus = 0;
}

RadarView::~RadarView ()
{
    if(mAlarmType>0) {
        setAlarmType(0);
    }
}
static const char PDC_VOLUME_VALUE[] = "persist.pdc.volume";
void RadarView::update(void* p_data)
{
    Mutex::Autolock _l(mLock);
    mSurfaceDirty = true;

    PdcData* pdc = (PdcData*)p_data;
    for(int i=0; i<pdc->number; i++) {
        ALOGD("RadarView update() sensor: i=%d type=%d, value=%d, status=%d", i,
            pdc->sensor[i].sensor.type, pdc->sensor[i].sensor.value,pdc->sensor[i].sensor.status);
		mRadarStatus += pdc->sensor[i].sensor.status;
        switch(pdc->sensor[i].sensor.type) {
            case RADAR_ROL:
                mRadarData.ROL = pdc->sensor[i].sensor.value;
                mRadarsStatus.ROL_STATUS = pdc->sensor[i].sensor.status;
                break;
            case RADAR_ROR:
                mRadarData.ROR = pdc->sensor[i].sensor.value;
                mRadarsStatus.ROR_STATUS= pdc->sensor[i].sensor.status;
                break;
            case RADAR_RML:
                mRadarData.RML = pdc->sensor[i].sensor.value;
                mRadarsStatus.RML_STATUS = pdc->sensor[i].sensor.status;
                break;
            case RADAR_RMR:
                mRadarData.RMR = pdc->sensor[i].sensor.value;
                mRadarsStatus.RMR_STATUS = pdc->sensor[i].sensor.status;
                break;
        }
    }
    char value[5];
    property_get(PDC_VOLUME_VALUE, value, "1");
    mAlarmVolume = atoi(value);

    updateImageAndAlarmType();
    mAlarmType = (uint8_t)(pdc->alarmType);
    applyAlarmType();
    mCondition.broadcast();
}

bool RadarView::threadLoop_l()
{
    int i, j;
    ALOGD("RadarView threadLoop_l()");
    
    mSurfaceDirty = true;
    while(!exitPending()) 
    {
        {
            Mutex::Autolock _l(mLock);
            while(!mSurfaceDirty&&!exitPending())
            {
                if(mCondition.waitRelative(mLock, milliseconds(100))==NO_ERROR)
                    break;
            }
            if(exitPending()) {
                break;
            }
            mSurfaceDirty = false;
        }

        glClearColor(0, 0, 0, 0);
        glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
        glEnable(GL_TEXTURE_2D);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        for(i=0; i<3; i++) {
            if(initNoticeTexture(i)!=NO_ERROR) {
                ALOGE("initNoticeTexture i=%d failed!", i);
                break;
            }
        }
		drawNoticeTexture();

            for(i=0; i<6; i++) {
                if(mSegInfo[i].currentIndex!=-1) {
                    if(initTexture(i)!=NO_ERROR) {
                        ALOGE("initTexture i=%d failed!", i);
                        break;
                    }
                    ALOGD("drawTexture i=%d,currentIndex=%d", i,mSegInfo[i].currentIndex);
                    drawTexture(&mSegInfo[i]);
                }
            }
        
        eglSwapBuffers(mDisplay, mSurface);
    }

    for(i=0; i<6; i++) {
        for(j=0; j<4; j++) {
            if(mSegInfo[i].texIds[j]!=0) {
                glDeleteTextures(1, &mSegInfo[i].texIds[j]);
                mSegInfo[i].texIds[j] = 0;
            }
        }
    }

    for(i=0; i<3; i++) {
        glDeleteTextures(1, &mNoticeSegmentInfo[i].texId);
        mNoticeSegmentInfo[i].texId = 0;
    }
    
    return true;
}

void  RadarView:: updateImageAndAlarmType ()
{
    mAlarmType = ALARM_MUTE;
    if(mRadarsStatus.ROL_STATUS == 1) {
        mSegInfo[2].currentIndex = 2;
    }else if(mRadarData.ROL>O_SEGMENT2) {
        mSegInfo[2].currentIndex = -1;
    }else if(mRadarData.ROL> O_SEGMENT1){
        mSegInfo[2].currentIndex = 0;
        mAlarmType = ALARM_4HZ;
    }else{
        mSegInfo[2].currentIndex = 1;
        mAlarmType = ALARM_LONG_BEEP;
    }

    if(mRadarsStatus.RML_STATUS == 1) {
        mSegInfo[3].currentIndex = 3;
    }else if(mRadarData.RML>M_SEGMENT3){
        mSegInfo[3].currentIndex = -1;
    }else if(mRadarData.RML>M_SEGMENT2) {
        mSegInfo[3].currentIndex = 0;
        if(mAlarmType< ALARM_2HZ){
            mAlarmType = ALARM_2HZ;
        }
    }else if(mRadarData.RML > M_SEGMENT1){
        mSegInfo[3].currentIndex = 1;
        if(mAlarmType< ALARM_4HZ){
            mAlarmType = ALARM_4HZ;
        }
    }else{
        mSegInfo[3].currentIndex = 2;
        mAlarmType = ALARM_LONG_BEEP;
    }

    if(mRadarsStatus.ROR_STATUS == 1) {
        mSegInfo[4].currentIndex = 2;
    }else if(mRadarData.ROR>O_SEGMENT2) {
        mSegInfo[4].currentIndex = -1;
    }else if(mRadarData.ROR > O_SEGMENT1){
        mSegInfo[4].currentIndex = 0;
        if(mAlarmType< ALARM_4HZ){
            mAlarmType = ALARM_4HZ;
        }
    }else{
        mSegInfo[4].currentIndex = 1;
        mAlarmType = ALARM_LONG_BEEP;
    }


    if(mRadarsStatus.RMR_STATUS == 1) {
        mSegInfo[5].currentIndex = 3;
    }else if(mRadarData.RMR>M_SEGMENT3){
        mSegInfo[5].currentIndex = -1;
    }else if(mRadarData.RMR>M_SEGMENT2) {
        mSegInfo[5].currentIndex = 0;
        if(mAlarmType< ALARM_2HZ){
            mAlarmType = ALARM_2HZ;
        }
    }else if(mRadarData.RMR > M_SEGMENT1){
        mSegInfo[5].currentIndex = 1;
        if(mAlarmType< ALARM_4HZ){
            mAlarmType = ALARM_4HZ;
        }
    }else{
        mSegInfo[5].currentIndex = 2;
        mAlarmType = ALARM_LONG_BEEP;
    }
}

#define PDC_ALARM_VOLUME_SET 0x80000017
#define PDC_ALARM_TYPE_SET 0x80000016
status_t RadarView::applyAlarmType()
{
    int fd = -1;
    int cnt = 0;

    while(fd<0&&cnt<5) {
        fd = open(RADAR_PATH, O_RDWR);
        cnt++;
        if(fd<0) {
            ALOGE("Open radar file failed! cnt=%d", cnt);
            sleep(200);
        }
    }
    if(fd<0) {
        ALOGE("Open radar file failed!");
        goto exit;
    }
    ALOGD("PDC_ALARM_TYPE_SET fd=%d, type=%d, volume=%d", fd,mAlarmType,mAlarmVolume);
    if(ioctl(fd, PDC_ALARM_VOLUME_SET, &mAlarmVolume)==-1) {
        ALOGE("PDC_VOLUME_SET failed");
        goto exit;
    }
    if(ioctl(fd, PDC_ALARM_TYPE_SET, &mAlarmType)==-1) {
        ALOGE("PDC_VOLUME_SET failed");
        goto exit;
    }
    exit:
    if(fd>0) {
        close(fd);
        return -1;
    }
    return 0;
}

int RadarView::setAlarmType(uint8_t type) {
    int fd = -1;
    int cnt = 0;

    while(fd<0&&cnt<5) {
        fd = open(RADAR_PATH, O_RDWR);
        cnt++;
        if(fd<0) {
            ALOGE("Open radar file failed! cnt=%d", cnt);
            sleep(200);
        }
    }
    if(fd<0) {
        ALOGE("setAlarmType Open radar file failed!");
        goto exit;
    }
    ALOGD("PDC_ALARM_TYPE_SET fd=%d, type=%d", fd,type);
    if(ioctl(fd, PDC_ALARM_TYPE_SET, &type)==-1) {
        ALOGE("PDC_ALARM_TYPE_SET failed! type=%d", type);
        goto exit;
    }
    exit:
    if(fd>0) {
        close(fd);
        return -1;
    }
    return 0;
}

status_t RadarView ::initTexture(int i){
    SegmentInfo * segInfo = &mSegInfo[i];
    int index = segInfo->currentIndex;
    GLuint* textureId = &(segInfo->texIds[index]);
    const char* name=segInfo->images[index];
    
    if(*textureId!=0) {
        return NO_ERROR;
    }

    char path[50] = "images/pas/";
    strcat(path, name);
    ALOGD("image=%s", path);
    Asset* asset = mAssets.open(path, Asset::ACCESS_BUFFER);
    if (asset == NULL)
        return NO_INIT;
    SkBitmap bitmap;
    SkImageDecoder::DecodeMemory(asset->getBuffer(false), asset->getLength(),
            &bitmap, kUnknown_SkColorType, SkImageDecoder::kDecodePixels_Mode);
    asset->close();
    delete asset;

    // ensure we can call getPixels(). No need to call unlock, since the
    // bitmap will go out of scope when we return from this method.
    bitmap.lockPixels();

    const int w = bitmap.width();
    const int h = bitmap.height();
    const void* p = bitmap.getPixels();

    GLint crop[4] = { 0, h, w, -h };
    segInfo->w = w;
    segInfo->h = h;
    if(i==0) { //car
       segInfo->x = (mWidth-w)/2;
       segInfo->y = mHeight/2 - h -108;
    }else {//back_BG and other
       segInfo->x = (mWidth-w)/2;
       segInfo->y = mSegInfo[0].h - h - 88;
    }

    glGenTextures(1, textureId);
    glBindTexture(GL_TEXTURE_2D, *textureId);
    ALOGD("colorType=%d" , bitmap.colorType());
    switch (bitmap.colorType()) {
        case kAlpha_8_SkColorType:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_ALPHA, w, h, 0, GL_ALPHA,
                    GL_UNSIGNED_BYTE, p);
            break;
        case kARGB_4444_SkColorType:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA,
                    GL_UNSIGNED_SHORT_4_4_4_4, p);
            break;
        case kN32_SkColorType:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA,
                    GL_UNSIGNED_BYTE, p);
            break;
        case kRGB_565_SkColorType:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, w, h, 0, GL_RGB,
                    GL_UNSIGNED_SHORT_5_6_5, p);
            break;
        default:
            break;
    }

    glTexParameteriv(GL_TEXTURE_2D, GL_TEXTURE_CROP_RECT_OES, crop);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    return NO_ERROR;
}

void RadarView::drawTexture(SegmentInfo* segInfo)
{
    int x,y,w,h, index;
    x = segInfo->x;
    y = segInfo->y;
    w = segInfo->w;
    h = segInfo->h;
    index = segInfo->currentIndex;
    //ALOGD("texIds=%d" , segInfo->texIds[index]);
    glBindTexture(GL_TEXTURE_2D, segInfo->texIds[index]);
    glDrawTexiOES(x,y,0,w,h);
}

status_t RadarView::initNoticeTexture(int i)
{
    int x,y,w,h;
	NoticeSegmentInfo * segInfo = &mNoticeSegmentInfo[i];
    GLuint* textureId = &(segInfo->texId);
    const char* name=segInfo->image;
    
    if(*textureId!=0) {
        ALOGD("textureId!=0 returen,name=%s",name);
        return NO_ERROR;
    }
	ALOGD("initNoticeTexture name=%s", name);
	char path[50] = "images/pas/";
    strcat(path, name);
    ALOGD("image=%s", path);
	Asset* asset = mAssets.open(path, Asset::ACCESS_BUFFER);
    if (asset == NULL) {
        ALOGD("initNoticeTexture asset == NULL name=%s", path);
        return NO_INIT;
	}
    SkBitmap bitmap;
    SkImageDecoder::DecodeMemory(asset->getBuffer(false), asset->getLength(),
            &bitmap, kUnknown_SkColorType, SkImageDecoder::kDecodePixels_Mode);
    asset->close();
    delete asset;	
	w = bitmap.width();
    h = bitmap.height();
	x = 0;
	y = mHeight/2 - 88;
	const void* p = bitmap.getPixels();
	ALOGD("initNoticeTexture name=%s,w=%d,h=%d,x=%d,y=%d,bitmap.colorType()=%d", name,w,h,x,y,bitmap.colorType());
	GLint crop[4] = { 0, y, w, -h };
	glGenTextures(1, textureId);
	glBindTexture(GL_TEXTURE_2D, *textureId);
    switch (bitmap.colorType()) {
        case kAlpha_8_SkColorType:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_ALPHA, w, h, 0, GL_ALPHA,
                    GL_UNSIGNED_BYTE, p);
            break;
        case kARGB_4444_SkColorType:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA,
                    GL_UNSIGNED_SHORT_4_4_4_4, p);
            break;
        case kN32_SkColorType:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA,
                    GL_UNSIGNED_BYTE, p);
            break;
        case kRGB_565_SkColorType:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, w, h, 0, GL_RGB,
                    GL_UNSIGNED_SHORT_5_6_5, p);
            break;
        default:
            break;
    }
	glTexParameteriv(GL_TEXTURE_2D, GL_TEXTURE_CROP_RECT_OES, crop);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    return NO_ERROR;
}

void RadarView::drawNoticeTexture()
{
    int intex = 0;
    if(mRadarSysStatus == 1) {
        intex = 1;
    }else if(mRadarStatus >= 1){
        intex = 2;
        mRadarStatus = 0;
    }
    ALOGD("drawNoticeTexture intex=%d,mRadarStatus=%d",intex,mRadarStatus);
    glBindTexture(GL_TEXTURE_2D, mNoticeSegmentInfo[intex].texId);
    glDrawTexiOES(0,552,0,960,88);
}

}
