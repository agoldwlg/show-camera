#ifndef PAS_VIEW_BASE_H_
#define PAS_VIEW_BASE_H_

#include <stdint.h>
#include <sys/types.h>

#include <utils/Thread.h>
#include <binder/IBinder.h>

#include <androidfw/AssetManager.h>


#include <EGL/egl.h>
#include <GLES/gl.h>
#include <GLES2/gl2.h>

#include <GLES/glext.h>
//#include <EGL/eglext.h>

namespace android {

class Surface;
class SurfaceComposerClient;
class SurfaceControl;

class ViewBase: public Thread, public IBinder::DeathRecipient
{
public:
    ViewBase(const char* name);
    virtual     ~ViewBase();
    virtual void display();
    virtual void dismiss();
    virtual void update(void* data) = 0;
    virtual bool isDisplaying();
    GLuint loadShader(int type, const char* source);
    GLuint createProgram(const char* vSrc, const char* fSrc);
    void setLayout(int x, int y, int width, int height);
    void setLayer(uint32_t layer);
    void setUseAlpha(bool alpha);
	void checkGlError(int line);

protected:
    EGLDisplay mDisplay;
    EGLContext mContext;
    EGLSurface mSurface;
    EGLConfig   mConfig;
    sp<SurfaceComposerClient>       mSession;
    sp<SurfaceControl> mFlingerSurfaceControl;
    sp<Surface> mFlingerSurface;
    const char* mName;

    int         mWidth;
    int         mHeight;
    int mX;
    int mY;
    uint32_t mLayer;
    bool mUseAlpha;

    virtual bool threadLoop_l() = 0;

private:
    virtual bool        threadLoop();
    virtual status_t    readyToRun();
    virtual void        onFirstRef();
    virtual void        binderDied(const wp<IBinder>& who);
};

};
#endif
