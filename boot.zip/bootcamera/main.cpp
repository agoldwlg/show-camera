/*
* 
*/
#define LOG_TAG "PAS_main"

#include <binder/IPCThreadState.h>
#include <binder/ProcessState.h>
#include <binder/IServiceManager.h>
#include <cutils/properties.h>
#include <sys/resource.h>
#include <utils/Log.h>
#include <utils/threads.h>

#include "EventHandle.h"
#include "EventHub.h"

using namespace android;

// ---------------------------------------------------------------------------
static void checkService(const char* name)
{
    sp<IServiceManager> sm = defaultServiceManager();
    sp<IBinder> binder = NULL;
    for(;;) {
    binder = sm->checkService(String16(name));
    if(binder!=0) break;
        ALOGW("Service %s not published, waiting ?", name);
        usleep(100000);
    }
}
int main()
{
    setpriority(PRIO_PROCESS, 0, ANDROID_PRIORITY_DISPLAY);

    sp<ProcessState> proc(ProcessState::self());
    ProcessState::self()->startThreadPool();

    checkService("SurfaceFlinger");
    checkService("media.camera");

    sp<EventHandle> eventhandle = new EventHandle();
    sp<EventHub> eventhub = new EventHub(eventhandle);

    IPCThreadState::self()->joinThreadPool();

    return 0;
}


