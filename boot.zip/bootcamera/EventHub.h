/*
* Description:
* Autor:
*/
#ifndef PAS_EVENT_HUB_H_
#define PAS_EVENT_HUB_H_

#include <utils/Thread.h>
#include <binder/Parcel.h>

#include "Event.h"
#include "EventHandle.h"



namespace android {

class InputEventReader: public Thread, public virtual RefBase {
    public:
        InputEventReader(const sp<EventHandle> &handle);
        ~InputEventReader();
    private:
        sp<EventHandle> mEventHandle;

        virtual void onFirstRef();
        virtual bool threadLoop();
        int scanDirAndOpenDevice();
        int openRvcStatusFile();
};

class EventHub: public Thread, public virtual RefBase {
private:
    sp<EventHandle> mEventHandle;
    sp<InputEventReader> mInputReader;
    State mAccState;
    int readMessage(int fd, uint8_t* buffer, int len);
    bool processMessage(Parcel& p);


public:
    EventHub(const sp<EventHandle>& handle);
    ~EventHub();

    virtual void onFirstRef();
    virtual bool threadLoop();
};

};
#endif
