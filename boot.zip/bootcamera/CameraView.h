#ifndef _CAMERA_VIEW_H_
#define _CAMERA_VIEW_H_

#include <stdint.h>
#include <sys/types.h>


#include <gui/GLConsumer.h>
#include <camera/Camera.h>

#include "ViewBase.h"
#include "TrackView.h"


namespace android {

class CameraView: public ViewBase, public GLConsumer::FrameAvailableListener
{
private:
    AssetManager mAssets;

public:
    /*struct CameraViewListener : public virtual RefBase {
        // See IConsumerListener::onFrame{Available,Replaced}
        virtual void onCameraViewDisplay() = 0;
        virtual void onCameraViewDismiss() = 0;
    };*/

    CameraView (bool withTrack);
    virtual ~ CameraView ();
    virtual bool threadLoop_l();
    virtual void update(void* data);

private:
    virtual void onFrameAvailable(const BufferItem& /* item */);
    bool startCamera();
    bool stopCamera();

    void initTexture();
    status_t initCameraDefaultTexture();
	bool startCameraErrorDisplayPicture ();
    sp<Camera> mCamera;
    Mutex mLock;
    Condition mCondition;
    bool mFrameAvailable;
	bool mStartFlag;

    GLuint mTexId;
    GLuint mCameraDefaultTexId;

    sp<GLConsumer> mSurfaceTexture;
    sp<IGraphicBufferProducer> mProducer;
    sp<IGraphicBufferConsumer> mConsumer;
    sp<TrackView> mTrackView;
};

};
#endif
