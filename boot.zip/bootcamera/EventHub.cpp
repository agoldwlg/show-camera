/*
 *
 */

#define LOG_TAG "PAS_EventHub"

// #define LOG_NDEBUG 0
#include <fcntl.h>
#include <cutils/sockets.h>
#include <binder/Parcel.h>
#include <linux/input.h>
#include <utils/Log.h>
#include <dirent.h>
#include <stdio.h>
#include <string.h>

#include "EventHub.h"
#include "Event.h"
#include <sys/stat.h>
#include <sys/inotify.h>
#define test_bit(bit, array)    (array[bit/8] & (1<<(bit%8)))

/* this macro computes the number of bytes needed to represent a bit array of the specified size */
#define sizeof_bit_array(bits)  ((bits + 7) / 8)

//static const char* device_name = "/dev/input/event1";
static const char *DEVICE_PATH = "/dev/input";
static const char *BACKSERVICE_RVC_STATUS_FILE = "/data/backservice_rvc_status";

namespace android {

InputEventReader::InputEventReader(const sp < EventHandle > & handle)
{
    mEventHandle = handle;
}

InputEventReader::~InputEventReader()
{
    mEventHandle.clear();
}

void InputEventReader::onFirstRef() {
        run("PAS_InputEventReader", PRIORITY_DISPLAY);
}

int InputEventReader::openRvcStatusFile()
{
    int fd;
    fd = open(BACKSERVICE_RVC_STATUS_FILE, O_RDWR | O_CLOEXEC);
    if(fd < 0) {
        ALOGE("could not open backservice_rvc_status %s\n",strerror(errno));
        return -1;
    }
	return fd;
}

int InputEventReader::scanDirAndOpenDevice()
{
    char devname[PATH_MAX];
    char buffer[80];
    char *filename;
    int fd;
    DIR *dir;
    struct dirent *de;
    dir = opendir(DEVICE_PATH);
    if(dir == NULL)
        return -1;
    strcpy(devname, DEVICE_PATH);
    filename = devname + strlen(devname);
    *filename++ = '/';
    while((de = readdir(dir))) {
        if(de->d_name[0] == '.' &&
           (de->d_name[1] == '\0' ||
            (de->d_name[1] == '.' && de->d_name[2] == '\0')))
            continue;
        strcpy(filename, de->d_name);
        fd = open(devname, O_RDWR | O_CLOEXEC);
        if(fd < 0) {
            ALOGE("could not open %s, %s\n", filename, strerror(errno));
            return -1;
        }
        memset(buffer,'\0', 80);
        if(ioctl(fd, EVIOCGNAME(sizeof(buffer) - 1), &buffer) < 1) {
               //fprintf(stderr, "could not get device name for %s, %s\n", devicePath, strerror(errno));
        } else {
            buffer[sizeof(buffer) - 1] = '\0';
            if(!strcmp(buffer, "egar-input")){
                ALOGE("Found device %s\n", filename);
                return fd;
            }
        }
        close(fd);
    }
    closedir(dir);
    return -1;
}
bool InputEventReader::threadLoop()
{
    
    int fd;
	int fd_rvc;
    int wd;
    int rvc_status = 0;
    int sw = 0x17;
    State reverse_state;

    uint8_t swState[sizeof_bit_array(SW_MAX + 1)];

    memset(swState, 0, sizeof(swState));
    fd = scanDirAndOpenDevice();
    if(fd < 0) {
        ALOGE("Open input device egar-input failed!!!" );
        return false;
    }
    if (ioctl(fd, EVIOCGSW(sizeof(swState)), swState) >= 0) {
        int down = swState[sw/8] & (1<<(sw%8));
        reverse_state =( down==0 ? STATE_OFF : STATE_ON);
        ALOGD("Got initialized reverse event:%s", reverse_state==STATE_ON?"STATE_ON":"STATE_OFF");
        mEventHandle->processEvent(EVENT_REVERSE, &reverse_state);
    }

    fd_rvc = inotify_init();
    if(fd_rvc < 0) {
        ALOGE("Fail to initialize inotify /data/backservice_rvc_status !" );
        return false;
    }
    wd = inotify_add_watch(fd_rvc,BACKSERVICE_RVC_STATUS_FILE,IN_MODIFY);
    if(wd<0) {
        ALOGE("Can't add watch for /data/backservice_rvc_status !" );
        return false;
    }
    int ret, res;
    fd_set rSet;
    
    struct timeval timeout;
    struct input_event event;
    char rvc[2];
    char buffer[512];
	int nfds = fd>fd_rvc ? (fd+1) : (fd_rvc+1);
    int fdrvc;
    ALOGD("fd=%d,fd_rvc=%d",fd,fd_rvc);
    while(!exitPending()) {
        FD_ZERO(&rSet);
        FD_SET(fd, &rSet);
        FD_SET(fd_rvc, &rSet);
        timeout.tv_sec = 0;
        timeout.tv_usec = 100000;
        rvc_status = 0;
        ret = select(nfds, &rSet, NULL, NULL, &timeout);
        if(ret>0) {//can be read
            if(FD_ISSET(fd, &rSet)){
                res = read(fd, &event, sizeof(event));
                    if(res < (int)sizeof(event)) {
                        ALOGE("Can not get event!!!");
                        return false;
                    }
                    if(event.type==EV_SW && event.code==0x17) {
                        reverse_state =( event.value==0 ? STATE_OFF : STATE_ON);
                        ALOGD("Got reverse event:%s", reverse_state==STATE_ON?"STATE_ON":"STATE_OFF");
                        mEventHandle->processEvent(EVENT_REVERSE, &reverse_state);
                    }
					ALOGE("read res=%d",res);
            }
			if(FD_ISSET(fd_rvc, &rSet)){
				read(fd_rvc, &buffer, 512);              
                fdrvc = openRvcStatusFile();
                res = read(fdrvc, &rvc, 1);
                    rvc_status = atoi(rvc);				
					reverse_state =( rvc_status==1 ? STATE_ON : STATE_OFF);
                    mEventHandle->processEvent(EVENT_RVC_STATUS, &reverse_state);
					ALOGE("read rvc_status=%d",rvc_status);
                close(fdrvc);
                FD_CLR(fd_rvc, &rSet);
            }
        } else if(ret==0 || errno == EINTR) {//timeout
            continue;
        } else {
            ALOGE("select error!(%s)", strerror(errno));
        }
    }
    close(fd);
	close(fd_rvc);
    return true;
    
}

EventHub::EventHub(const sp<EventHandle>& handle)
{
    mEventHandle = handle;
    mInputReader = new InputEventReader(handle);
    mAccState = STATE_UNKNOWN;
	    if (access(BACKSERVICE_RVC_STATUS_FILE, F_OK) == -1) {
        ALOGE("access file not exsit.");
        umask(0000);
        int fd = open(BACKSERVICE_RVC_STATUS_FILE, O_RDWR|O_CREAT|O_TRUNC, 0666);
        if (fd < 0) {
            ALOGE("could not open file: %s : %s", BACKSERVICE_RVC_STATUS_FILE, strerror(errno));
        }
        close(fd);
    }
}
EventHub::~EventHub()
{
    mEventHandle.clear();
    mInputReader.clear();
}
void EventHub::onFirstRef() {
        run("PAS_EventHub_PIL", PRIORITY_DISPLAY);
}

int EventHub::readMessage(int fd, uint8_t* buffer, int len) {
    int countRead;
    int offset;
    int remaining;
    int messageLength;

    if(buffer==NULL) {
        return -1;
    }

    offset = 0;
    remaining = 4;
    do {
        countRead = read(fd, buffer+offset, remaining);
        //ALOGD("countRead=%d", countRead);
        if (countRead < 0) {
            return -1;
        }
        offset += countRead;
        remaining -= countRead;
    } while (remaining > 0);

    messageLength = ((buffer[0] & 0xff) << 24) | ((buffer[1] & 0xff) << 16)
        | ((buffer[2] & 0xff) << 8) | (buffer[3] & 0xff);
    //ALOGD("messageLength=%d", messageLength);
    offset = 0;
    remaining = messageLength;
    if(messageLength > len) {
        ALOGE("Invalid message!!!");
    }
    do {
        countRead = read(fd, buffer+offset, remaining);
        if (countRead < 0) {
            return -1;
        }

        offset += countRead;
        remaining -= countRead;
    } while (remaining > 0);
    return messageLength;
}

bool EventHub::processMessage(Parcel& p)
{
    int type = p.readInt32();
    int msgId;
    if(type==1) {
        msgId = p.readInt32();
        switch(msgId) {
        case PIL_ACC_MSG://PIL_UNSOL_RESPONSE_STATUS_EVENT
        {
            int cnt = p.readInt32();
            if(cnt<4) {
                ALOGE("Invalid status event data. cnt=%d", cnt);
                return false;
            }
            p.readInt32();
            p.readInt32();
            p.readInt32();
            int status = p.readInt32();
            //ALOGE("Got acc state changed! status=%d", status);
            State acc_state = status==2? STATE_ON : STATE_OFF;
            if(mAccState!=acc_state) {
                 mAccState = acc_state;
                 ALOGE("Got acc state changed=%s", acc_state==STATE_ON?"STATE_ON":"STATE_OFF");
            }
            mEventHandle->processEvent(EVENT_ACC, &acc_state);
            break;
         }
        case PIL_PDC_MSG:
        {
            PdcData radar;
            radar.status = p.readInt32();
            radar.alarmType = p.readInt32();
            radar.number = p.readInt32();
            
            for(int i=0; i< radar.number; i++) {
                int n = p.readInt32();
                for(int j=0; j<n;j++){
                    radar.sensor[i].array[j] = p.readInt32();
                }
            }
            ALOGE("Got PDC msg status=%d, alarm_type=%d", radar.status, radar.alarmType);
            mEventHandle->processEvent(EVENT_RADAR, &radar);
            break;
        }
        case PIL_SWA_MSG:
        {
            SteeringData steeringData;
			steeringData.valid = p.readInt32();
            steeringData.ca = p.readFloat();
            ALOGE("Got SWA msg. steeringData.ca=%f,steeringData.valid=%d", steeringData.ca,steeringData.valid);
            mEventHandle->processEvent(EVENT_STEERING, &steeringData);
            break;
        }
        }
    }
    return true;
    
}
bool EventHub::threadLoop()
{
    int local_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    int socket_fd = -1;
    while(socket_fd<=0){
        socket_fd = socket_local_client_connect(local_fd, "pild2", ANDROID_SOCKET_NAMESPACE_RESERVED, SOCK_STREAM);
        if(socket_fd>0) {
            break;
        }
        usleep(100000);
    }
    uint8_t buf[255];
    Parcel p;
    int dataLen;
    while(!exitPending()) {
        dataLen = readMessage(socket_fd, buf, 255);
        p.setData(buf, dataLen);
        p.setDataPosition(0);
        processMessage(p);
    }
    close(socket_fd);
    return true;
}

}
